CREATE VIEW ProductsView AS
SELECT 
    products.IDProduct, 
    products.Name AS ProductName, 
    category.Name AS Category
FROM products
JOIN category ON products.IDCategory = category.IDCategory;