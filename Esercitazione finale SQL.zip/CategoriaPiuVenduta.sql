SELECT 
    category.Name AS Categoria, 
    SUM(sales.Quantity) AS QuantitaVendutaTotale
FROM sales
JOIN products ON sales.IDProduct = products.IDProduct
JOIN category ON products.IDCategory = category.IDCategory
GROUP BY Categoria
ORDER BY QuantitaVendutaTotale DESC
LIMIT 1;