CREATE VIEW GeoView AS
SELECT 
    states.IDState, 
    states.Name AS State, 
    regions.Name AS Region
FROM states
JOIN regions ON states.IDRegion = regions.IDRegion;