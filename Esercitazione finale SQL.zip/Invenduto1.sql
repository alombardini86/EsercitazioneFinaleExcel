SELECT products.Name
FROM products
LEFT JOIN sales ON products.IDProduct = sales.IDProduct
WHERE sales.IDProduct IS NULL;