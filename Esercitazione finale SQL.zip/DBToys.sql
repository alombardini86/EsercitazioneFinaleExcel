-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: toys
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `IDCategory` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDCategory`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Costruzioni','Set di mattoncini e kit per modellismo'),(2,'Giochi di Società','Giochi da tavolo, carte e puzzle per tutte le età'),(3,'Bambole e Peluche','Bambole classiche, action figure e morbidi peluche'),(4,'Veicoli e Piste','Macchinine radiocomandate, trenini e piste da corsa'),(5,'Educativi e Scientifici','Kit per esperimenti, giochi montessoriani e apprendimento');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `IDProduct` int NOT NULL AUTO_INCREMENT,
  `EAN` varchar(13) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `IDCategory` int DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`IDProduct`),
  KEY `fk_products_category_idx` (`IDCategory`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`IDCategory`) REFERENCES `category` (`IDCategory`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'8001234567011','Set Castello Medievale','Kit di mattoncini per costruire un castello con cavalieri',1,49.99),(2,'8001234567028','Stazione Spaziale','Modellino da costruire con astronauti e razzo',1,35.50),(3,'8001234567035','Auto da Corsa Technic','Set con ingranaggi funzionanti e sterzo',1,24.90),(4,'8001234567042','Cantiere Edile','Gru e ruspe da assemblare con 500 pezzi',1,42.00),(5,'8001234567059','Il Tesoro del Pirata','Gioco da tavolo di avventura per tutta la famiglia',2,29.99),(6,'8001234567066','Mistero in Villa','Gioco di investigazione e deduzione',2,19.90),(7,'8001234567073','Paroliere Junior','Gioco di parole educativo per bambini',2,14.50),(8,'8001234567080','Puzzle 1000 pz - Paesaggio','Puzzle ad alta definizione raffigurante le Dolomiti',2,12.00),(9,'8001234567097','Bambola Sofia','Bambola che parla con accessori per la pappa',3,39.00),(10,'8001234567103','Orsetto Peluche Gigante','Orsetto morbido alto 1 metro di colore marrone',3,45.00),(11,'8001234567110','Action Figure Super Eroe','Personaggio articolato alto 30cm con mantello',3,18.50),(12,'8001234567127','Set Casa delle Bambole','Struttura in legno con mobili in miniatura',3,89.00),(13,'8001234567134','Drone Radiocomandato','Mini drone con telecamera integrata HD',4,55.00),(14,'8001234567141','Pista Slot Racing','Pista a otto con due auto da corsa incluse',4,34.90),(15,'8001234567158','Treno Elettrico Vintage','Locomotiva a vapore con vagoni e binari',4,65.00),(16,'8001234567165','Camion Pompieri','Veicolo con scala estensibile e luci/suoni',4,27.00),(17,'8001234567172','Il Piccolo Chimico','Kit con 50 esperimenti scientifici sicuri',5,22.50),(18,'8001234567189','Microscopio Pro','Ingrandimento fino a 1200x con vetrini inclusi',5,38.00),(19,'8001234567196','Mappa Mondo Interattiva','Globo con penna parlante per geografia',5,49.00),(20,'8001234567202','Robot Solare 6-in-1','Kit per costruire robot alimentati dal sole',5,15.90);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `productsview`
--

DROP TABLE IF EXISTS `productsview`;
/*!50001 DROP VIEW IF EXISTS `productsview`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `productsview` AS SELECT 
 1 AS `IDProduct`,
 1 AS `ProductName`,
 1 AS `Category`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regions` (
  `IDRegion` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDRegion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` VALUES (1,'Europa Occidentale'),(2,'Europa Centrale'),(3,'Europa Meridionale'),(4,'Europa Settentrionale'),(5,'Europa Orientale');
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `IDSale` int NOT NULL AUTO_INCREMENT,
  `TransactionCode` varchar(50) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `IDProduct` int DEFAULT NULL,
  `IDState` int DEFAULT NULL,
  `Quantity` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDSale`),
  KEY `fk_sales_states1_idx` (`IDState`),
  KEY `fk_sales_products1_idx` (`IDProduct`),
  CONSTRAINT `fk_sales_products1` FOREIGN KEY (`IDProduct`) REFERENCES `products` (`IDProduct`),
  CONSTRAINT `fk_sales_states1` FOREIGN KEY (`IDState`) REFERENCES `states` (`IDState`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'TXN-2024-001','2024-02-15',1,3,2),(2,'TXN-2024-002','2024-03-10',5,1,1),(3,'TXN-2024-003','2024-05-22',13,2,1),(4,'TXN-2024-004','2024-06-05',17,7,3),(5,'TXN-2024-005','2024-08-14',9,5,1),(6,'TXN-2024-006','2024-11-30',20,4,5),(7,'TXN-2024-007','2024-12-12',15,8,1),(8,'TXN-2024-008','2024-12-20',2,3,2),(9,'TXN-2025-001','2025-01-15',3,1,4),(10,'TXN-2025-002','2025-02-28',11,2,2),(11,'TXN-2025-003','2025-04-10',19,6,1),(12,'TXN-2025-004','2025-05-18',6,7,2),(13,'TXN-2025-005','2025-07-04',14,5,1),(14,'TXN-2025-006','2025-09-22',10,3,1),(15,'TXN-2025-007','2025-10-05',18,4,2),(16,'TXN-2025-008','2025-11-15',4,1,1),(17,'TXN-2025-009','2025-12-24',12,8,1),(18,'TXN-2026-001','2026-01-02',8,3,10),(19,'TXN-2026-002','2026-01-05',7,2,3),(20,'TXN-2026-003','2026-01-08',8,5,2),(21,'TXN-2026-004','2026-01-10',4,7,1);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states` (
  `IDState` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(60) DEFAULT NULL,
  `IDRegion` int DEFAULT NULL,
  PRIMARY KEY (`IDState`),
  KEY `fk_states_regions1_idx` (`IDRegion`),
  CONSTRAINT `fk_states_regions1` FOREIGN KEY (`IDRegion`) REFERENCES `regions` (`IDRegion`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Regno Unito',4),(2,'Svezia',4),(3,'Italia',3),(4,'Spagna',3),(5,'Germania',2),(6,'Polonia',2),(7,'Francia',1),(8,'Olanda',1);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `productsview`
--

/*!50001 DROP VIEW IF EXISTS `productsview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `productsview` AS select `products`.`IDProduct` AS `IDProduct`,`products`.`Name` AS `ProductName`,`category`.`Name` AS `Category` from (`products` join `category` on((`products`.`IDCategory` = `category`.`IDCategory`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-10 18:53:25
