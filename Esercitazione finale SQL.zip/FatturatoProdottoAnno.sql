SELECT 
    products.Name, 
    YEAR(sales.Date) AS Year, 
    SUM(products.Price * sales.Quantity) AS Fatturato
FROM sales
JOIN products ON sales.IDProduct = products.IDProduct
GROUP BY products.Name, YEAR(sales.Date);