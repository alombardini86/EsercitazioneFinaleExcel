SELECT 
    sales.TransactionCode, 
    sales.Date, 
    products.Name, 
    category.Name, 
    states.Name, 
    regions.Name,
    CASE 
        WHEN DATEDIFF(CURRENT_DATE, sales.Date) > 180 THEN 'True' 
        ELSE 'False' 
    END AS maggiore_180gg
FROM sales
JOIN products ON sales.IDProduct = products.IDProduct
JOIN category ON products.IDCategory = category.IDCategory
JOIN states ON sales.IDState = states.IDState
JOIN regions ON states.IDRegion = regions.IDRegion;