SELECT products.Name
FROM products
WHERE products.IDProduct NOT IN (
    SELECT DISTINCT sales.IDProduct 
    FROM sales
);