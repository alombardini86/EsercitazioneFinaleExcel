SELECT 
    products.Name, 
    SUM(sales.Quantity)
FROM sales
JOIN products ON sales.IDProduct = products.IDProduct
WHERE YEAR(sales.Date) = (
    SELECT MAX(YEAR(sales.Date)) 
    FROM sales
)
GROUP BY products.Name
HAVING SUM(sales.Quantity) > (
    SELECT AVG(calcolo.TotaleQuantita)
    FROM (
        SELECT SUM(sales.Quantity) AS TotaleQuantita
        FROM sales
        WHERE YEAR(sales.Date) = (
            SELECT MAX(YEAR(sales.Date)) 
            FROM sales
        )
        GROUP BY sales.IDProduct
    ) AS calcolo
);