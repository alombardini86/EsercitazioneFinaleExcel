-- Se 0, non ci sono duplicati
SELECT COUNT(category.IDCategory) - COUNT(DISTINCT category.IDCategory) FROM category;

SELECT COUNT(products.IDProduct) - COUNT(DISTINCT products.IDProduct) FROM products;

SELECT COUNT(regions.IDRegion) - COUNT(DISTINCT regions.IDRegion) FROM regions;

SELECT COUNT(states.IDState) - COUNT(DISTINCT states.IDState) FROM states;

SELECT COUNT(sales.IDSale) - COUNT(DISTINCT sales.IDSale) FROM sales;