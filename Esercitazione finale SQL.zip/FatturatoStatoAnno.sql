SELECT 
    states.Name AS State, 
    YEAR(sales.Date) AS Year, 
    SUM(products.Price * sales.Quantity) AS Fatturato
FROM sales
JOIN states ON sales.IDState = states.IDState
JOIN products ON sales.IDProduct = products.IDProduct
GROUP BY states.Name, YEAR(sales.Date)
ORDER BY YEAR(sales.Date) ASC, SUM(products.Price * sales.Quantity) DESC;